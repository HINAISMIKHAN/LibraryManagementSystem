from flask import Flask, redirect, render_template, request, url_for, flash
import pymongo

# Mongo Db Connection

myclient = pymongo.MongoClient('mongodb://localhost:27017')
mydb = myclient['LMS1']
print(mydb.list_collection_names())

app = Flask(__name__)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/login')
def login():
    return render_template('login.html')
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        cursor = mydb.member.count_documents({"member_password":password})
        if cursor:
           return render_template('welcome.html')
        else:
            return  render_template('login.html')


    else:
        return render_template('login.html')


@app.route('/list', methods=['GET', 'POST'])
class Library:
    def __init__(self, listOfBooks):
        self.books = listOfBooks

@app.route('/search', methods=['GET', 'POST'])

def displayAvailableBooks(self):
    print("Books present in this library are: ")
    for book in self.books:
        print(" *" + book)

@app.route('/borrow', methods=['GET', 'POST'])
    def borrowBook(self, bookName):
        if bookName in self.books:
            print(f"You have been issued {bookName}. Please keep it safe and return it within 30 days")
            self.books.remove(bookName)
            return True
        else:
            print(
                "Sorry, This book is either not available or has already been issued to someone else. Please wait until the book is available")
            return False

#
# @app.route('/return', methods=['POST'])
#     def returnBook(self, bookName):
#         self.books.append(bookName)
#         print("Thanks for returning this book! Hope you enjoyed reading it. Have a great day!")
#
#
# @app.route('/borrow', methods=['GET', 'POST'])
# class Student:
#     def requestBook(self):
#         self.book = input("Enter the name of the book you want to borrow: ")
#         return self.book
#
#     def returnBook(self):
#         self.book = input("Enter the name of the book you want to return: ")
#         return self.book
#
#
#     centraLibrary = Library(["JavaScript", "PHP", "C++", "Python", "Java"])
#     student = Student()
#
# #
# class book:
#     bookStoreId = 0
#     bookTitle = ""
#     bookAuthor = ""
#     bookPublisher = ""
#     bookPrice = 0.0
#     bookCategory = ""
#     bookLanguage = ""
#     bookBorrowed = False
#
# #Constructor is a method in the class which is used to create object
#
#     def __init__(self, *book):
#         if len(book) == 1:
#             self.bookStoreId = book[0]#for search and delete
#         elif len(book) == 2:#for update and insert
#             self.bookStoreId = book[0]
#             self.bookAuthor = book[1]
#         elif len(book) == 6:#for update and insert
#             self.bookStoreId = int(book[0])
#             self.bookTitle = book[1]
#             self.bookAuthor = book[2]
#             self.bookPublisher = book[3]
#             self.bookLanguage = book[4]
#             self.bookCategory = book[5]
#
#
# @app.route('/insert', methods=['GET', 'POST'])
#     def InsertBook(self):
#         myclient = get_db_connection()
#         mydb = myclient.LMS
#         mycoll = mydb.book
#         try:
#             mycoll.insert_one({"book_id":self.bookStoreId, "title":self.bookTitle,"author":self.bookAuthor,\
#                                 "publisher":self.bookPublisher, "language": self.bookLanguage, "category":self.bookCategory})
#
#             return "This book has been inserted successfully"
#         except Exception:
#             print("problem in inserting")
# @app.route('/delete', methods=['Delete'])
#     def DeleteBook(self):
#         myclient = pymongo.MongoClient("mongodb://localhost:27017/")
#         mydb = myclient["LMS"]
#         mycoll = mydb["book"]
#         try:
#             myQuery = {'id': self.bookStoreId}#filter
#             mycoll.delete_one(myQuery)
#
#             return "Book Deleted"
#         except Exception:
#             print("problem in deleted")
# @app.route('/search', methods=['GET', 'POST'])
#     def SearchBook(self):
#         myclient = pymongo.MongoClient("mongodb://localhost:27017/")
#         mydb = myclient["LMS"]
#         mycoll = mydb["book"]
#         try:
#             myQuery = {'id': self.bookStoreId}  # filter
#             count = mycoll.count_documents(myQuery)
#             if count > 0:
#                 bookDetails = mycoll.find_one(myQuery)
#                 print(bookDetails)
#         except Exception:
#             print("problem in searching")
# @app.route('/update', methods=['GET', 'POST'])
#     def UpdateBook(self):
#         myclient = pymongo.MongoClient("mongodb://localhost:27017/")
#         mydb = myclient["LMS"]
#         mycoll = mydb["book"]
#         try:
#
#             myquery = {"book_id": self.bookStoreId}
#             newvalues = {"$set": {"title": self.bookTitle, "author": self.bookAuthor, "publisher": self.bookPublisher, "language"
#             : self.bookLanguage, "category": self.bookCategory}}
#
#             mycoll.update_one(myquery, newvalues)
#
#             return "This book has been updated successfully"
#         except Exception:
#             print("problem in updating")
#



if __name__ == "__main__":
    app.run(debug=True)