
from flask import Flask, redirect, render_template, request, url_for, flash
import pymongo

myclient = pymongo.MongoClient('mongodb://localhost:27017')
mydb = myclient['LMS1']
print(mydb.list_collection_names())
app = Flask(__name__)


@app.route('/')
def index():
    return render_template('code/index.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        cursor = mydb.member.count_documents({"member_password": password})
        if cursor:
            return render_template('welcome.html')
        else:
            return render_template('login.html')


    else:
        return render_template('login.html')


@app.route('/about', methods=['GET', 'POST'])
def about():
    return render_template('about.html')


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    return render_template('signup.html')


@app.route('/contact', methods=['GET', 'POST'])
def contact():
    return render_template('contact.html')


if __name__ == "__main__":
    app.run(debug=True)
